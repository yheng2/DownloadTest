function test() {
    if(document.getElementById("webkit-h1").style.color == "lightblue") {
        document.getElementById("webkit-h1").style.color = "coral";
    } else {
        document.getElementById("webkit-h1").style.color = "lightblue";
    }
}
